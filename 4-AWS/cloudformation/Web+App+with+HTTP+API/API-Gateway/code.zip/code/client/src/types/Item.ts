export interface Item {
  itemId: string
  name: string
  price: string
  done: boolean
}
