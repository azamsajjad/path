export interface UpdateItemRequest {
  itemId: string
  name: string
  price: string
  done: boolean
}